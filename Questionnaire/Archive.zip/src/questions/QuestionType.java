package questions;

public enum QuestionType {
    TRUE_FALSE,

    MULTIPLE_CHOICE,
    MULTIPLE_SELECT,
    LIKERT,
}





