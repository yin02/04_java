public interface Hashable {
  // returns the hash code
  int computeHashCode();
}